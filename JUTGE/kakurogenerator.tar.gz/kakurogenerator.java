//package Dominio;


import javax.swing.text.BadLocationException;
import java.io.*;
import java.sql.Timestamp;
import java.util.*;

public class kakurogenerator {

    /*  r: valor random que generaremos para cada Celda
        k: Kakuro genera y devuelve la clase */
    private static Random r = new Random();
    private Kakuro k;
    private final int n;
    private final int m;
    private final int p;
    private final int maxCellNum;

    public kakurogenerator(Kakuro k) throws BadLocationException {
        this.k = k;
        n = k.getAltura();
        m = k.getAnchura();
        String d = String.valueOf(k.getDificultad());
        if (d.equals("FACIL")) {
            p = 4;
            maxCellNum = 7;
        } else if (d.equals("INTERMEDIO")) {
            p = 4;
            maxCellNum = 8;
        } else {
            p = 3;
            maxCellNum = 9;
        }
        // inicializamos k con el valor de Celdas blancas vacías
        initialiseMatrixKakuro(k);
        generate();
        // guardamos k en un fichero de texto
        writeBoard();
    }

    // TODO: cambiar nombre a getGeneratedKakuro
    public Kakuro getGeneratedKakuro() { return this.k; }

    public void initialiseMatrixKakuro(Kakuro k) {
        // inicializamos cada Celda para no acceder
        // a un valor null en el algoritmo
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
                k.createCell(i,j,"?");
    }

    public void generate() throws BadLocationException {
        /*  incializamos la arista superior e izquierda con celdas negras vacías
            ya que ninguna de estas puede ser blanca */
        k.createCell(0,0,"*");
        for (int j = 1; j < m; j++) k.createCell(0,j,"*");
        for (int i = 1; i < n; i++) k.createCell(i,0,"*");

        /* estas variables nos permitiran contar cuantas celdas blancas seguidas
           por fila y por columna tenemos para no superar la maxNumCell */
        int[] rowWhiteCells = new int[n];
        int[] colWhiteCells = new int[m];

        fillKakuro(1,1, rowWhiteCells, colWhiteCells);
        //System.out.println("Sale del fillKakuro");
        //Tablero t = new Tablero(k);
        //t.setFrame();
        fillSums(0,0);
        setSums();
        //printBoard();
    }

    public boolean fillKakuro(int i, int j, int[] rowWhiteCells, int[] colWhiteCells) throws BadLocationException  {
        //estas variables nos marcaran si podemos cambiar de color
        boolean whiteForced = false;
        boolean blackForced = false;
        if (i == n) return true;
        else if (j == m) return fillKakuro(i+1, 1, rowWhiteCells, colWhiteCells);
        else {

            /*if (i >= n-2) {
                Tablero t = new Tablero(k);
                t.setFrame();
            }*/

            int rowLast = rowWhiteCells[i - 1];
            int colLast = colWhiteCells[j - 1];

            //System.out.println("Cell: " + i + ", " + j);
            //System.out.println("Row: " + rowWhiteCells[i-1] + ", Col: " + colWhiteCells[j-1]);

            // si la celda puede ser negra (no genera una celda de 1 suma)
            if (!hasSum1(i,j)) {

                if ((j == m-1 && k.isNegra(i, j-1)) ||
                        (i == n-1 && k.isNegra(i-1, j))) {
                    blackForced = true;
                    //System.out.println("Black Forced");
                    k.createCell(i, j, "*");
                    rowWhiteCells[i - 1] = 0;
                    colWhiteCells[j - 1] = 0;
                } else if (r.nextInt(10) <= p) {
                    //System.out.println("Black");
                    k.createCell(i, j, "*");
                    rowWhiteCells[i - 1] = 0;
                    colWhiteCells[j - 1] = 0;
                } else {
                    //System.out.println("White");
                    rowWhiteCells[i - 1]++;
                    colWhiteCells[j - 1]++;
                }
                // tenemos que marcar la celda obligatoriamente blanca
            } else {
                if ((j == m-1 && k.isNegra(i, j-1)) ||
                        (i == n-1 && k.isNegra(i-1, j)))
                    //tendria que ser blanca y negra a la vez
                    return false;
                //System.out.println("Blanca forzada");
                whiteForced = true;
                rowWhiteCells[i - 1]++;
                colWhiteCells[j - 1]++;
                //System.out.println("White Forced");
            }

            /*si hemos puesto una blanca hemos actualizado las sumas
            y puede que ahora nos pasemos del maximo, asi que lo miramos
             */
            if (k.isBlanca(i,j)) {
                boolean[] check = check(i,j,rowLast,colLast,rowWhiteCells,colWhiteCells,whiteForced);

                /* si no hemos podido cambiar a negra significa que no es solucion valida */
                if (!check[0]) return false;

                /* si hemos podido cambiar a negra significa que forzamos que sea negra
                ya que con blanca se pasa, pero podemos seguir
                 */
                if (check[1]) blackForced = true;
                //System.out.println("Black Forced");
            }

            boolean connected;
            /* si es negra sabemos que cumple las sumas, pero tenemos que mirar
            que siga teniendo una componente conexa unica, solo asi tenemos un
            kakuro valido
             */
            if (k.isNegra(i,j)) {
                if ( (i >= n/2 && hasWall(i-1,j, new boolean[n][m])) || (i == n-2 && colBlack(i,j)) ||
                        (j == m-2 && rowBlack(i,j)) || hasSum1(i,j)) {
                    //if (hasWall(i-1,j, new boolean[n][m])) System.out.println("Entra per hasWall");
                    k.createCell(i, j, "?");
                    if (blackForced) {
                     // System.out.println("Sale por blackForced");
                        rowWhiteCells[i - 1] = rowLast;
                        colWhiteCells[j - 1] = colLast;
                        return false;
                    } else {
                        whiteForced = true;
                        rowWhiteCells[i - 1] = rowLast+1;
                        colWhiteCells[j - 1] = colLast+1;
                        //System.out.println("White Forced");

                        boolean[] check = check(i,j,rowLast,colLast,rowWhiteCells,colWhiteCells,true);
                        //si nos pasamos de la suma no puede ser ni blanca ni negra
                        if (!check[0]) return false;
                    }
                }
                connected = findConnected(k, new boolean[n][m]);
                /*si no es connexo al ponerla negra intentamos ponerla blanca y
                miramos que pasa
                 */
                if (!connected) {
                    k.createCell(i, j, "?");
                    /*  si la negra era forzada no puede ser blanca, por tanto no puede
                        ser con ningun valor, reseteamos la celda y volvemos
                    */
                    if (blackForced) {
                        rowWhiteCells[i - 1] = rowLast;
                        colWhiteCells[j - 1] = colLast;
                        return false;
                    }
                    //la ponemos blanca
                    rowWhiteCells[i - 1] = rowLast+1;
                    colWhiteCells[j - 1] = colLast+1;
                    whiteForced = true;
                    //System.out.println("White Forced");

                    //miramos que al forzar que sea blanca cumplimos las sumas
                    boolean[] check = check(i,j,rowLast,colLast,rowWhiteCells,colWhiteCells,true);
                    //si nos pasamos de la suma no puede ser ni blanca ni negra
                    if (!check[0]) return false;

                    /*si la hemos podido poner a blanca y cumplimos todos los checks
                    seguimos hacia la siguiente iteracion, devolvemos directo porque
                    ya sabemos que negra no puede ser
                    */
                    return fillKakuro(i,j+1, rowWhiteCells, colWhiteCells);
                }
            }

            /*si llegamos aqui significa que somos conexos y cumplimos las sumas
            ahora solo nos falta mirar si podemos seguir, y si no podemos cambiar
            de color si no lo hemos hecho ya
             */
            boolean valid = fillKakuro(i, j + 1, rowWhiteCells, colWhiteCells);
            //System.out.println("Hemos vuelto a la celda "+i+" "+j);
            /*  si no es valido hemos de probar a cambiar el color de la celda
                y si no se puede volvemos atras
             */
            if (!valid) {
                if (k.isNegra(i,j)) {
                    k.createCell(i, j, "?");
                    // si no podemos cambiar volvemos
                    if (blackForced){
                        rowWhiteCells[i - 1] = rowLast;
                        colWhiteCells[j - 1] = colLast;
                        return false;
                    }
                    rowWhiteCells[i - 1] = rowLast+1;
                    colWhiteCells[j - 1] = colLast+1;
                    //System.out.println("White Forced");

                    boolean[] check = check(i, j, rowLast, colLast, rowWhiteCells, colWhiteCells, true);

                    // si al cambiar no cumplimos las sumas volvemos
                    if (!check[0]) return false;
                } else {
                    // si no podemos cambiar volvemos atras
                    boolean[][] wall = new boolean[n][m];
                    boolean hasWall = hasWall(i-1,j, wall);
                    if (whiteForced || (i >= n/2 && hasWall) || (i == n-2 && colBlack(i,j)) ||
                            (j == m-2 && rowBlack(i,j)) || hasSum1(i,j)) {
                        //System.out.println("Sale cuando era blanca por whiteForced");
                        //if (hasWall) fix_wall(i-1, j, wall);
                        rowWhiteCells[i - 1] = rowLast;
                        colWhiteCells[j - 1] = colLast;
                        return false;
                    }

                    // ponemos la celda a negro
                    k.createCell(i, j, "*");
                    rowWhiteCells[i - 1] = 0;
                    colWhiteCells[j - 1] = 0;

                    // miramos que aun tengamos una componente conexa
                    connected = findConnected(k,new boolean[n][m]);
                    // si no es conexo no puede ser negro ni blanco, volvemos
                    if (!connected) {
                        k.createCell(i, j, "?");
                        rowWhiteCells[i - 1] = rowLast;
                        colWhiteCells[j - 1] = colLast;
                        return false;
                    }
                }
                /* si una vez hecho el cambio llegamos hasta aqui, podemos
                volver a llamar con el color cambiado
                 */
                return fillKakuro(i, j+1, rowWhiteCells, colWhiteCells);
            }
            return true;
        }
    }

    /*private void fix_wall(int i, int j, boolean[][] visited){
        //asumim que les seguents son negres
        for (int ii = i; ii < n ; ii++){
            k.createCell(ii, j, "*");
        }
        if (!findConnected(k, new boolean[n][m])) System.out.println("No es connexo al poner negras en el wall, va bien");
        //intenta conectar el wall (i=1 i = n-3)
        for (int ii = 1; ii < n-2 && !findConnected(k, new boolean[n][m]); ii++){
            for (int jj = 1; jj < m && !findConnected(k, new boolean[n][m]); j++){
                if(visited[ii][jj]) trywhite(ii,jj);
            }
        }
    }*/

   /* private boolean trywhite(int i, int j){
        //k.createCell(i, j, "?");
        int rowLast = 0;
        int left = j-1;
        while (k.isBlanca(i,left)){
            rowLast++;
            left--;
        }
        int right = j+1;
        while (k.isBlanca(i,right)){
            rowLast++;
            right++;
        }
        if (rowLast >= 9) return false;


        int colLast = 0;
        int up = j-1;
        while (k.isBlanca(up,j)){
            colLast++;
            up--;
        }
        int down = j+1;
        while (k.isBlanca(down,j)){
            colLast++;
            down++;
        }
        if (colLast > 9) return false;
        if (rowLast == 0 && colLast == 0){
            //suma unica, hay que tratarlo
            if (!trywhite(i+1,j)){
                trywhite(i,j+1);
            }
        }
        k.createCell(i, j, "?");
        return true;
    }*/

    //se puede poner mucho mas bonito sacando factor comun del codigo repetido en los dos checks
    //ya sea con otro boolean para mirar si hemos cambiado o con boolean ? case 1 | case 2
    private boolean[] check(int i, int j, int rowLast, int colLast, int[] rowWhiteCells, int[] colWhiteCells,
                            boolean whiteForced){
        /*
        res[0] -> indica si el check es cierto y podemos seguir o es falso
        res[1] -> indica si hemos tenido que forzar el cambio a negra para poder seguir
         */
        boolean[] res = new boolean[2];
        res[0] = true;
        res[1] = false;

        if (rowWhiteCells[i-1] > maxCellNum || colWhiteCells[j-1] > maxCellNum ||
                (j == m-1 && k.isNegra(i, j-1)) || (i == n-1 && k.isNegra(i-1, j))) {
            //no podemos seguir ni cambiar, restauramos a blanca no inicializada
            if (whiteForced){
                rowWhiteCells[i - 1] = rowLast;
                colWhiteCells[j - 1] = colLast;
                res[0] = false;
                //no podemos cambiar a negra porque ya sabemos que hemos forzado blanca
                return res;
            }
            //Si no era forced era blanca aleatoria, probamos con negra
            res[1] = true;
            k.createCell(i,j,"*");
            rowWhiteCells[i-1] = 0;
            colWhiteCells[j-1] = 0;
            return res;
        }
        return res;
    }

    private boolean hasSum1(int i, int j) {
        return ((k.isBlanca(i-1, j) && k.isNegra(i-2, j)) ||
                (k.isBlanca(i, j-1) && k.isNegra(i, j-2))
                //(i == n-1 && k.isNegra(i-1, j)) ||
                //(j == m-1 && k.isNegra(i, j-1))
        );
    }

    private boolean rowBlack(int i, int j) {
        for (int jj = 1; jj < j; jj++)
            if (k.isBlanca(i, jj)) return false;
        return true;
    }

    private boolean colBlack(int i, int j) {
        for (int ii = 1; ii < i; ii++)
            if (k.isBlanca(ii, j)) return false;
        return true;
    }

    private boolean hasWall(int i, int j, boolean[][] visited) {
        visited = new boolean[n][m];
        findWall(i,j, visited);
        for (int jj = 1; jj < m; jj++) {
            if (k.isNegra(1, jj) && visited[1][jj]) {
                //System.out.println("Wall at: " + i + ", " + j);
                return true;
            }
        }
        return false;
    }

    private void findWall(int i, int j, boolean visited[][]) {

        if (i < 1 || j < 0 || j == m || visited[i][j] || k.isBlanca(i,j)) return;
        visited[i][j] = true;
        findWall(i - 1, j, visited);
        findWall(i - 1, j - 1, visited);
        findWall(i - 1, j + 1, visited);
        findWall(i, j + 1, visited);
        findWall(i, j - 1, visited);
    }

    private boolean findConnected(Kakuro k, boolean[][] visited) {

        int i = 1;
        int j = 1;
        while(k.isNegra(i,j)) {
            if (j < m-1) j++;
            else {
                i++;
                j = 1;
            }
        }
        isConnected(i,j,k,visited);

        for (i = 1; i < n; i++)
            for (j = 1; j < m; j++) {
                if (!visited[i - 1][j - 1] && k.isBlanca(i, j)) return false;
            }
        return true;
    }

    private void isConnected(int i, int j, Kakuro k, boolean[][] visited) {
        if (i < 1 || i >= n || j < 1 || j >= m || visited[i-1][j-1] || k.isNegra(i,j)) return;
        visited[i-1][j-1] = true;
        isConnected(i + 1, j, k, visited);
        isConnected(i, j + 1, k, visited);
        isConnected(i - 1, j, k, visited);
        isConnected(i, j - 1, k, visited);
    }

    private boolean fillSums(int i, int j){
        if (i >= n) return true;
        if (j >= m) return fillSums(i+1,0);

        int index = 0;
        BitSet rowAux = new BitSet(9);
        BitSet colAux = new BitSet(9);
        if (k.isNegra(i,j)){
            //si tenim una negra seguida d'una blanca aquesta es suma
            if (j < m-1 && k.isBlanca(i,j+1)){
                BitSet canF = new BitSet(9);
                //podemos poner todos los numeros al inicio
                canF.set(0,9);
                if (i < n-1 && k.isBlanca(i+1,j)){
                    BitSet canC = new BitSet(9);
                    canC.set(0,9);
                    k.setCellValue(i,j,"C0F0");
                    k.setCellCandidatesF(i, j, canF);
                    k.setCellCandidatesC(i,j,canC);
                }
                else{
                    k.setCellValue(i,j,"F0");
                    k.setCellCandidatesF(i, j, canF);
                }
            }
            else if (i < n-1 && k.isBlanca(i+1,j)){
                BitSet canC = new BitSet(9);
                canC.set(0,9);
                k.setCellValue(i,j,"C0");
                k.setCellCandidatesC(i,j,canC);
            }
        }
        else{
            //agafem els candidats de la celda anterior
            BitSet candidatesF = k.getCellCandidatesF(i,j-1);
            BitSet candidatesC = k.getCellCandidatesC(i-1,j);
            k.setCellCandidatesF(i, j, candidatesF);
            k.setCellCandidatesC(i, j, candidatesC);

            //mirem si de la interseccio queda algun numero
            BitSet intersection = (BitSet) candidatesC.clone();
            intersection.and(candidatesF);

            if (intersection.cardinality() <= 0){
                return false;
            }
            //miramos si para todos los numeros que pueden ir en la celda alguno genera solucion
            boolean valid = false;
            while (!valid && intersection.cardinality() > 0) {
                //agafem un random dels que queda a la interseccio
                int rnd = new Random().nextInt(intersection.cardinality());
                index = intersection.nextSetBit(rnd);
                if (index < 0) index = intersection.previousSetBit(rnd);
                //ens guardem el candidat a un auxiliar per si els hem de restaurar tots
                candidatesC.clear(index);
                colAux.set(index);
                candidatesF.clear(index);
                rowAux.set(index);
                k.setCellValue(i, j, Integer.toString(index + 1));

                //actualitzem la interseccio
                intersection = (BitSet) candidatesC.clone();
                intersection.and(candidatesF);

                valid = fillSums(i, j + 1);
                if (valid) return valid;
                else k.setCellValue(i, j, "?");
            }
            //si no hem pogut posar cap numero restaurem els candidats en aquest punt i anem endarrere
            if (!valid){
                candidatesC.or(colAux);
                candidatesF.or(rowAux);
            }
            return valid;
        }

        boolean valid = fillSums(i,j+1);
        return valid;
    }

    private void setSums(){
        for (int i = 0; i < n; i++){
            for (int j = 0; j < m; j++) {
                if (k.isNegra(i, j)) {
                    int row = addRow(i, j);
                    int col = addCol(i, j);
                    if (row != 0) {
                        if (col != 0) {
                            k.setCellValue(i, j, "C" + col + "F" + row);
                        } else k.setCellValue(i, j, "F" + row);
                    } else if (col != 0) k.setCellValue(i, j, "C" + col);
                    else k.setCellValue(i, j, "*");
                }
            }
        }
        for (int i = 0; i<n; i++)
            for (int j = 0; j < m; j++){
                if(k.isBlanca(i,j)) k.setCellValue(i,j,"?");
            }
    }

    /*  devuelve la suma de uno de los conjuntos de celdas blancas
        consecutivas en una fila */
    public int addRow(int row, int col) {
        // sum: suma total de la fila
        int sum = 0;
        // inBounds: nos dice si seguimos consultando celdas blancas
        boolean inBounds = true;
        for (int j = col + 1; j < m && inBounds; j++) {
            if (k.isBlanca(row,j))
                sum += Integer.parseInt(k.getCellValue(row,j));
            else inBounds = false;
        }
        return sum;
    }

    /*  devuelve la suma de uno de los conjuntos de celdas blancas
        consecutivas en una columna */
    public int addCol(int row, int col) {
        // sum: suma total de la columna
        int sum = 0;
        // inBounds: nos dice si seguimos consultando celdas blancas
        boolean inBounds = true;
        for (int i = row + 1; (i < n) && inBounds; i++) {
            if (k.isBlanca(i,col))
                sum += Integer.parseInt(k.getCellValue(i,col));
            else inBounds = false;
        }
        return sum;
    }

    public void writeBoard(){
        try {
            BufferedWriter output;
            String folder = "Kakuros";
            File directory = new File(folder);
            /*  almacenamos los kakuros en un directorio llamado Kakuros por
                tanto, si no está creado el directorio lo creamos */
            if (!directory.exists()) directory.mkdir();
            File file = new File(folder + "/Board" + n + "x"
                    + m + k.getDificultad() + ".txt");
            output = new BufferedWriter(new FileWriter(file));

            output.write(n + "," + m);
            output.newLine();
            for(int i = 0; i < n; i++) {
                for (int j = 0; j < m; j++) {
                    if (j == 0) output.write(k.getCellValue(i,j));
                    else output.write("," + k.getCellValue(i,j));
                }
                output.newLine();
            }
            output.close();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void printBoard() {
        System.out.println(n + "," + m);
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (j == 0) System.out.print(k.getCellValue(i,j));
                else System.out.print("," + k.getCellValue(i,j));
            }
            System.out.println();
        }
    }

    public static void main(String args[]) throws BadLocationException {

        /*Scanner s = new Scanner(System.in).useDelimiter(",|\\n| ");
        int altura = s.nextInt();
        int anchura = s.nextInt();
        int dif = s.nextInt();
        String d = null;
        if (dif == 1) d = "FACIL";
        else if (dif == 2) d = "INTERMEDIO";
        else if (dif ==3 ) d = "DIFICIL";
        else System.out.println("Aprende a usar el generator crack");
        //int xd = s.nextInt();*/

        int altura = Integer.parseInt(args[0]);
        int anchura = Integer.parseInt(args[1]);;
        int dif = Integer.parseInt(args[2]);
        String d = null;
        if (dif == 1) d = "FACIL";
        else if (dif == 2) d = "INTERMEDIO";
        else if (dif ==3 ) d = "DIFICIL";
        else System.out.println("Aprende a usar el generator crack");
        int xd = Integer.parseInt(args[3]);

        Timestamp begining = new Timestamp(System.currentTimeMillis());
        Kakuro k = new Kakuro(altura, anchura, d);
        kakurogenerator kg = new kakurogenerator(k);
        kg.printBoard();
        Timestamp end = new Timestamp(System.currentTimeMillis());
        System.out.println("Time: " + (end.getTime() - begining.getTime()) + " ms.");
        //Tablero t = new Tablero(k);
        //t.setFrame();
    }
}